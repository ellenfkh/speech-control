#!/usr/bin/env python2
from array import array
import site
site.PREFIXES.append("/Users/silver/dev/homebrew")
try:
    import pocketsphinx
except:
    pass
import pocketsphinx as ps
import pyaudio
import subprocess

def send_word(word):
    word_dict_shift = {
            "HEP": ")",
            "BAT": "!",
            "DOOP": "@",
            "LIK": "#",
            "TEED": "$",
            "MID": "%",
            "TIP": "^",
            "UN": "&",
            "BACK": "(",
        }
    word_dict_cmd = {
        "YAM": "q",
        "POKE": "w",
        "HEAT" : "e",
        "SIT" : "r",
        "TIM" : "t",
        "GOK" : "y",
        "LAG" : "u",
        "RED" : "i",
        "DOOP": "o",
        "BACK": "p"
    }
    header = """
activate application "Mjolnir"
tell application "System Events"
"""
    footer = """
end tell
activate application frontAppName
"""

    if word in word_dict_cmd:
        num = word_dict_cmd[word]
        cmd = """
    keystroke "%s" using {control down, command down}
""" % num
    else:
        num = word_dict_shift[word]
        cmd = """
    keystroke "%s" using control down
""" % num

    full = header + cmd + footer
    subprocess.call(["osascript", "-e", full])

def done(pieces, decoder):
    decoder.start_utt('')
    full_utt = False
    for buf in pieces:
        decoder.process_raw(buf, False, full_utt)
    decoder.end_utt()
    hyp, x, score = decoder.get_hyp()
    if hyp:
        for w in hyp.split():
            print w
            send_word(w)

decoder = ps.Decoder(dict="custom.dict", jsgf="grammar.jsgf", samprate="16000",
                     hmm="hub4wsj_sc_8kadapt")

p = pyaudio.PyAudio()

FRAMES = 4096
stream = p.open(format=pyaudio.paInt16, channels=1, rate=16000, input=True,
                frames_per_buffer=FRAMES)
MIN_VOLUME = 6000
stream.start_stream()
pieces = []
while True:
    buf = stream.read(int(FRAMES * 1.5))
    if not buf:
        break
    if max(array('h', buf)) > MIN_VOLUME:
        pieces.append(buf)
    if max(array('h', buf)) < MIN_VOLUME and pieces:
        done(pieces, decoder)
        pieces = []
