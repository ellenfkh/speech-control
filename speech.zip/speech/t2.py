
import subprocess

def send_word(word):
    word_dict_shift = {
            "HEP": ")",
            "BAT": "!",
            "DOOP": "@",
            "LIK": "#",
            "TEED": "$",
            "MID": "%",
            "TIP": "^",
            "UN": "&",
            "BACK": "(",
        }
    word_dict_cmd = {
        "HEP": "q",
        "BAT": "w",
        "DOOP": "e",
        "LIK": "r",
        "TEED": "t",
        "MID": "y",
        "TIP": "u",
        "UN": "i",
        "BACK": "o",
    }
    if word in word_dict_cmd:
        num = word_dict_cmd[word]
        cmd = """
activate application "Mjolnir"
tell application "System Events"
    keystroke "%s" using {control down, command down}
end tell
""" % num
    else:
        num = word_dict_shift[word]
        cmd = """
activate application "Mjolnir"
tell application "System Events"
    keystroke "%s" using control down
end tell
""" % num

    print cmd
    subprocess.call(["osascript", "-e", cmd])

w = """
HEP
BAT
DOOP
LIK
TEED
MID
TIP
UN
BACK""".split()
import time
for word in w:
    send_word(word)
    time.sleep(0.5)

