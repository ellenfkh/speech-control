import pyaudio

CHUNK = 512
WIDTH = 2
CHANNELS = 2
RATE = 44100
RECORD_SECONDS = 3

p = pyaudio.PyAudio()

stream = p.open(format=p.get_format_from_width(WIDTH),
                channels=CHANNELS,
                rate=RATE,
                input=True,
                output=True,
                frames_per_buffer=CHUNK)

print("* recording")

data = []
for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
    data.append(stream.read(CHUNK))
print("* playing")
for x in data:
    stream.write(x, CHUNK)
stream.write(''.join(data), CHUNK)
print len(''.join(data))
print len(data)
print len(data[0])

print("* done")

stream.stop_stream()
stream.close()

p.terminate()
