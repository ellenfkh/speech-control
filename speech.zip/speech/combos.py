import itertools
import random
import os
import subprocess

# Get all words that are in our vocab list
with open("words", "r") as f:
    lines = [line.strip() for line in f.readlines()]

# Find the next filename to write
data_dir = "training-data"
try:
    next_name = max(int(name[:-4]) for name in os.listdir(data_dir)
                    if name.endswith(".txt")) + 1
except:
    next_name = 1


def record(string, num):
    with open(data_dir + "/" + str(num) + ".txt", "w") as f:
        f.write(string)
    output_name = data_dir + "/" + str(num) + "_raw.wav"
    print str(num) + ": " + string
    cmds = ["rec", "-r", "16000", "-e", "signed-integer", "-b", "16", "-c", "1", output_name]
    proc = subprocess.Popen(cmds)
    raw_input()
    proc.kill()
    out_name = data_dir + "/" + str(num) + ".wav"
    subprocess.call(["ffmpeg", "-i", output_name, "-r", "8000", "-ac", "1", out_name])
    os.remove(output_name)

# Get all sequences
seqs = list(itertools.combinations_with_replacement(lines, 8))
random.shuffle(seqs)

for s in seqs:
    record(" ".join(s), next_name)
    next_name += 1
